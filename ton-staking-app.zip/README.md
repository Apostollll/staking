# TON Staking dApp

Приложение для стейкинга Jetton токенов в сети TON.

## Локальный запуск

```bash
npm install
npm run dev
```

---
